import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIClient {
    public static void main(String[] args) {
        try {
            // Define the URL of the API endpoint
            URL url = new URL("https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/day/2023-01-09/2023-01-09?apiKey=LpLxmrARONFWxOriE1k4eMzBCDEG2cBT");

            // Create a HttpURLConnection object to open a connection to the API
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // Set up reading from the connection
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            // Read the response from the API
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            // Close the reader and the connection
            reader.close();
            connection.disconnect();

            // Extracting and printing the opening price from the response
            double openingPrice = parseResponse(response.toString());
            System.out.println("Opening price of AAPL on 2023-01-09: $" + openingPrice);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to parse the JSON response and extract the opening price
    private static double parseResponse(String responseData) {
        // Parse the JSON response as a JSON array
        System.out.println(responseData);
        JSONObject jsonObject = new JSONObject(responseData);
        JSONArray jsonArray = jsonObject.getJSONArray("results");

        // Assume the first element in the array contains the data for the specified date
        JSONObject firstDataPoint = jsonArray.getJSONObject(0);

        // Extract the opening price from the first data point
        double openingPrice = firstDataPoint.getDouble("o");

        return openingPrice;
    }
}