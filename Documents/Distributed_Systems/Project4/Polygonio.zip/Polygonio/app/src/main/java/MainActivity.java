// Name: Dhriti Gada
// Andrew id: dgada

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import ds.edu.polygonio.R;

public class MainActivity extends AppCompatActivity {

    private String stockSymbol; // Variable to store selected stock symbol

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Spinner and Button
        Spinner spinner = findViewById(R.id.spinner);
        Button button = findViewById(R.id.button);

        // Set up array of stock symbols
        final String[] stocks = {"AAPL", "GOOGL", "MSFT"};

        // Set up adapter for the Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, stocks);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Set up item selection listener for the Spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Update the stockSymbol variable with the selected stock symbol
                stockSymbol = stocks[position];
                Log.d("MainActivity", "Selected stock symbol: " + stockSymbol);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing if nothing is selected
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stockSymbol != null) {
                    Log.d("MainActivity", "Selected stock symbol: " + stockSymbol);
                    getStockData(stockSymbol);
                } else {
                    // Handle the case where no stock symbol is selected
                    Log.d("MainActivity", "No stock symbol selected");
                }
            }
        });
    }

    private void getStockData(final String stockSymbol) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Construct URL for Polygon.io API
                    String apiKey = "https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/day/2023-01-09/2023-01-09?apiKey=LpLxmrARONFWxOriE1k4eMzBCDEG2cBT";
                    URL url = new URL("https://api.polygon.io/v2/aggs/ticker/" + stockSymbol + "/range/1/day/2023-01-09/2023-01-09?apiKey=" + apiKey);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.connect();

                    // Read the response
                    InputStream inputStream = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line).append("\n");
                    }
                    reader.close();

                    // Parse JSON response
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    // Extract desired information from jsonResponse and handle accordingly

                    // Update UI on the main thread
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            // Handle the extracted information accordingly
                        }
                    });
                } catch (IOException | JSONException e) {
                    Log.e("MainActivity", "Error ", e);
                }
            }
        }).start();
    }
}