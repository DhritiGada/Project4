/**
 * Name: Dhriti Gada
 * Andrew ID : dgada
 * This class fetches stock data from the Polygonio API using HTTP requests asynchronously.
 * It provides a callback mechanism for handling the result or errors.
 */

package ds.edu.project4task2;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class StockDataFetcher {

    /**
     * Callback interface to handle the result or errors of fetching stock data.
     */
    public interface Callback {
        void onResult(String symbol, double open, double close, double high, double low, long volume, long timestamp);
        void onError(String message);
    }

    /**
     * Fetches stock data from the server based on the provided symbol.
     *
     * @param symbol    The stock symbol for which to fetch data.
     * @param callback  The callback to handle the result or errors.
     */
    public static void fetchStockData(String symbol, Callback callback) {
        AsyncTask<String, Void, JSONObject> task = new AsyncTask<String, Void, JSONObject>() {
            @Override
            protected JSONObject doInBackground(String... symbols) {
                try {
                    // Construct the URL for the API request
                    URL url = new URL("https://api.polygon.io/v2/aggs/ticker/" + symbols[0] + "/range/1/day/2022-01-12/2023-01-12?adjusted=true&sort=asc&limit=120&apiKey=YOUR_API_KEY");

                    // Open connection and read data from the API
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    urlConnection.disconnect();

                    // Parse JSON response
                    return new JSONObject(stringBuilder.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(JSONObject response) {
                super.onPostExecute(response);

                // Handle the JSON response
                try {
                    if (response != null) {
                        JSONArray results = response.optJSONArray("results");
                        if (results != null && results.length() > 0) {
                            JSONObject result = results.getJSONObject(0);
                            double open = result.optDouble("o", 0.0);
                            double close = result.optDouble("c", 0.0);
                            double high = result.optDouble("h", 0.0);
                            double low = result.optDouble("l", 0.0);
                            long volume = result.optLong("v", 0);
                            long timestamp = result.optLong("t", 0);

                            // Pass stock data to the callback
                            callback.onResult(symbol, open, close, high, low, volume, timestamp);
                        } else {
                            callback.onError("No data found for the symbol: " + symbol);
                        }
                    } else {
                        callback.onError("Error loading data");
                    }
                } catch (Exception e) {
                    callback.onError("Error parsing data");
                }
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
                callback.onError("Task cancelled");
            }
        }.execute(symbol);
    }
}