// Name: Dhriti Gada
// Andrew id: dgada

package ds.edu.project4task2;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private String stockSymbol; // Variable to store selected stock symbol
    private TextView textViewOpen, textViewClose, textViewHigh, textViewLow, textViewVolume, textViewTimestamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize TextViews
        textViewOpen = findViewById(R.id.textViewOpen);
        textViewClose = findViewById(R.id.textViewClose);
        textViewHigh = findViewById(R.id.textViewHigh);
        textViewLow = findViewById(R.id.textViewLow);
        textViewVolume = findViewById(R.id.textViewVolume);
        textViewTimestamp = findViewById(R.id.textViewTimestamp);

        // Initialize Spinner and Button
        Spinner spinner = findViewById(R.id.spinner);
        Button button = findViewById(R.id.button);

        // Set up array of stock symbols
        final String[] stocks = {"AAPL", "GOOGL", "MSFT"};

        // Set up adapter for the Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, stocks);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Set up item selection listener for the Spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Update the stockSymbol variable with the selected stock symbol
                stockSymbol = stocks[position];
                Log.d("MainActivity", "Selected stock symbol: " + stockSymbol);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing if nothing is selected
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stockSymbol != null) {
                    Log.d("MainActivity", "Selected stock symbol: " + stockSymbol);
                    getStockData(stockSymbol);
                } else {
                    // Handle the case where no stock symbol is selected
                    Log.d("MainActivity", "No stock symbol selected");
                }
            }
        });
    }

    private void getStockData(final String stockSymbol) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection urlConnection = null;
                BufferedReader reader = null;
                OutputStream outputStream = null;

                try {
                    // Codespace URL
                    URL url = new URL("https://10.0.2.2:8080/stock-data-servlet");

                    // Open connection
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setDoOutput(true);
                    urlConnection.setDoInput(true);
                    urlConnection.connect();

                    // Create JSON object with stock symbol
                    JSONObject requestData = new JSONObject();
                    requestData.put("symbol", stockSymbol);

                    // Send request
                    outputStream = urlConnection.getOutputStream();
                    outputStream.write(requestData.toString().getBytes());

                    // Read the response
                    InputStream inputStream = urlConnection.getInputStream();
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line).append("\n");
                    }

                    // Parse JSON response
                    final JSONObject jsonResponse = new JSONObject(response.toString());

                    // Extract desired information from the JSON response
                    final double open = jsonResponse.getDouble("o");
                    final double close = jsonResponse.getDouble("c");
                    final double high = jsonResponse.getDouble("h");
                    final double low = jsonResponse.getDouble("l");
                    final long volume = jsonResponse.getLong("v");
                    final long timestamp = jsonResponse.getLong("t");

                    // Update UI on the main thread
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            // Handle the extracted information accordingly
                            textViewOpen.setText("Open: " + open);
                            textViewClose.setText("Close: " + close);
                            textViewHigh.setText("High: " + high);
                            textViewLow.setText("Low: " + low);
                            textViewVolume.setText("Volume: " + volume);
                            textViewTimestamp.setText("Timestamp: " + timestamp);
                        }
                    });

                    // Log request and response information
                    logRequestResponse(requestData.toString(), response.toString());

                } catch (IOException | JSONException e) {
                    Log.e("MainActivity", "Error ", e);
                } finally {
                    // Close connections
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                    try {
                        if (reader != null) {
                            reader.close();
                        }
                        if (outputStream != null) {
                            outputStream.close();
                        }
                    } catch (IOException e) {
                        Log.e("MainActivity", "Error closing stream", e);
                    }
                }
            }
        }).start();
    }

    private void logRequestResponse(String request, String response) {
        // Get current timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Log request and response information
        Log.d("MainActivity", "Request Timestamp: " + timestamp);
        Log.d("MainActivity", "Request: " + request);
        Log.d("MainActivity", "Response: " + response);
    }
}
