// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import org.bson.Document;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "dashboardServlet", value = "/dashboard")
public class DashboardServlet extends HttpServlet {

    private MongoCollection<Document> collection;

    @Override
    public void init() throws ServletException {
        try {
            // Connect to MongoDB Atlas
            MongoClient client = MongoClients.create("mongodb+srv://Dhriti_28:<password>@cluster0.agmir6c.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
            // Get database and collection
            MongoDatabase database = client.getDatabase("Project4Task2");
            collection = database.getCollection("logInfo");
        } catch (Exception e) {
            // Handle initialization error
            throw new ServletException("Error initializing MongoDB connection", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from MongoDB
        List<Document> data = getDataFromMongoDB();

        // Pass data to JSP file
        request.setAttribute("data", data);
        // For example, you can set attributes and forward the request
        request.setAttribute("message", "Welcome to the dashboard!");
        RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
        dispatcher.forward(request, response);
    }

    // Retrieve data from MongoDB collection
    private List<Document> getDataFromMongoDB() {
        List<Document> data = new ArrayList<>();
        try {
            // Retrieve data from MongoDB collection
            collection.find().into(data);
        } catch (Exception e) {
            // Handle error
        }
        return data;
    }
}
