// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "DashboardServlet", value = "/dashboard")
public class DashboardServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(DashboardServlet.class.getName());

    private MongoCollection<Document> collection;

    @Override
    public void init() throws ServletException {
        try {
            // Connect to MongoDB Atlas
            String connectionString = "mongodb+srv://Dhriti_28:Heyheyhey@123!@cluster0.lot2aed.mongodb.net/?retryWrites=true&w=majority";
            ServerApi serverApi = ServerApi.builder()
                    .version(ServerApiVersion.V1)
                    .build();

            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(connectionString))
                    .serverApi(serverApi)
                    .build();

            // Create a new client and connect to the server
            MongoClient client = MongoClients.create(settings);

            // Get database and collection
            MongoDatabase database = client.getDatabase("Project4Task2");
            collection = database.getCollection("logInfo");
        } catch (Exception e) {
            // Handle initialization error
            throw new ServletException("Error initializing MongoDB connection", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from MongoDB
        List<Document> data = getDataFromMongoDB();

        // Pass data to JSP file
        request.setAttribute("data", data);
        // For example, you can set attributes and forward the request
        request.setAttribute("message", "Welcome to the dashboard!");
        RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
        dispatcher.forward(request, response);
    }

    // Retrieve data from MongoDB collection
    private List<Document> getDataFromMongoDB() {
        List<Document> data = new ArrayList<>();
        try {
            // Retrieve data from MongoDB collection
            collection.find().into(data);
        } catch (Exception e) {
            // Handle error
            logger.log(Level.SEVERE, "Error retrieving data from MongoDB", e);
        }
        return data;
    }
}
