// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "stockDataServlet", value = "/stock-data-servlet")
public class StockDataServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(StockDataServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from client
        String stockSymbol = request.getParameter("stockSymbol");
        logger.log(Level.INFO, "Received stock symbol from client: " + stockSymbol);

        long startTime = System.currentTimeMillis();

        try {
            // Log request details
            logger.log(Level.INFO, "Request received at: " + startTime);
            logger.log(Level.INFO, "Request from: " + request.getHeader("User-Agent"));
            logger.log(Level.INFO, "HTTP Method: " + request.getMethod());
            logger.log(Level.INFO, "Remote Host: " + request.getRemoteHost());

            logger.log(Level.INFO, "Sending request to Polygon.io API for stock symbol: " + stockSymbol);
            StockDataModel stockDataModel = new StockDataModel();
            String stockData = stockDataModel.getStockData(stockSymbol);
            request.setAttribute("stockData", stockData);

            // Pass data to JSP file
            RequestDispatcher dispatcher = request.getRequestDispatcher("stock-data.jsp");
            dispatcher.forward(request, response);
        } finally {
            // Log total processing time
            long endTime = System.currentTimeMillis();
            logger.log(Level.INFO, "Total processing time: " + (endTime - startTime) + " milliseconds");

            // Log to MongoDB
            logToMongoDB(stockSymbol, startTime, endTime, request.getHeader("User-Agent"), request.getMethod(), request.getRemoteHost());
        }
    }

    // Logging Data to MongoDB Document
    private void logToMongoDB(String stockSymbol, long startTime, long endTime, String userAgent, String method, String remoteHost) {
        // Implement MongoDB logging here
    }
}