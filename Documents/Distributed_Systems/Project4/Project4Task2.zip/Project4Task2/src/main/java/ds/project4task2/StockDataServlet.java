// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import com.google.gson.JsonObject;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "StockDataServlet", urlPatterns = {"/stock", "/GetStocks", "/getDashBoard"})
public class StockDataServlet extends HttpServlet {

    @Override
    public void init() {
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            // Get the path of the request URL
            String path = request.getServletPath();
            // Get the value of the stock symbol parameter from the request
            String symbol = request.getParameter("symbol");
            // Create a JsonObject to store stock data
            JsonObject stockData = new JsonObject();
            // String to store the next view to be displayed
            String nextView = "";

            // Check the path of the request
            if (path.contains("stock")) {
                // Get the current time for request timestamp
                String requestReceivedTime = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss").format(new Date());
                // Get the request URL
                String requestUrl = request.getRequestURL().toString();
                // Get the user-agent header from the request
                String userAgent = request.getHeader("User-Agent");

                // Check if the symbol parameter is not null and not empty
                if (symbol != null && !symbol.isEmpty()) {
                    // Call the method to fetch stock data from Polygon.io API
                    stockData = fetchPolygonData(symbol);
                }

                // Get the current time for response timestamp
                String responseSentTime = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss").format(new Date());

                // Log the request and response details
                logRequestAndResponse(
                        requestReceivedTime, responseSentTime, userAgent,
                        symbol, stockData.toString(), requestUrl
                );

                // Set response content type to JSON
                response.setContentType("application/json");
                // Set character encoding to UTF-8
                response.setCharacterEncoding("UTF-8");
                // Write the stock data JSON to the response
                response.getWriter().write(stockData.toString());
            } else if (path.contains("GetStocks")) {
                // Code for handling other paths, if needed
                nextView = "stock.jsp"; // Example: Set the view for displaying stock data
            } else if (path.contains("getDashBoard")) {
                // Code for handling other paths, if needed
                nextView = "dashboard.jsp"; // Example: Set the view for displaying dashboard
            } else {
                // Default handling
                nextView = "result.jsp";
            }

            // Forwarding request to the next view
            if (!nextView.isEmpty()) {
                RequestDispatcher view = request.getRequestDispatcher(nextView);
                view.forward(request, response);
            }
        } catch (Exception e) {
            // Exception handling logic
            throw new ServletException("Error processing request", e);
        }
    }

    // Method to fetch data from Polygon.io API
    private JsonObject fetchPolygonData(String symbol) throws IOException {
        // Constructing the API URL
        String apiKey = "LpLxmrARONFWxOriE1k4eMzBCDEG2cBT";
        String apiUrl = "https://api.polygon.io/v2/aggs/ticker/" + symbol + "/range/1/day/2023-01-09/2023-01-09?apiKey=" + apiKey;

        // Making the HTTP request
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // Reading the response
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // Parsing the response to JsonObject
        JsonObject parsedData = new JsonObject(); // Parse the response here according to the API response format
        // Example:
        // parsedData.addProperty("symbol", symbol);
        // parsedData.addProperty("price", 150.25);
        // Add more properties as needed based on the actual response from the API

        return parsedData;
    }

    // Method to log request and response details
    private void logRequestAndResponse(String requestReceivedTime, String responseSentTime, String userAgent,
                                       String symbol, String result, String requestUrl) {
        // Log the request and response details to your database or file
        // For demonstration, let's just print the details to the console
        System.out.println("Request Received at: " + requestReceivedTime);
        System.out.println("Response Sent at: " + responseSentTime);
        System.out.println("User-Agent: " + userAgent);
        System.out.println("Symbol: " + symbol);
        System.out.println("Result: " + result);
        System.out.println("Request URL: " + requestUrl);
        // Add logic to store this information in your database or file
    }
}
