// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class StockDataModel {
    private static final String API_KEY = "LpLxmrARONFWxOriE1k4eMzBCDEG2cBT";
    private static final String API_URL = "https://api.polygon.io/v2/aggs/ticker/";

    public static JsonObject getStockData(String stockSymbol) {
        JsonObject stockData = new JsonObject();
        String apiUrl = API_URL + stockSymbol + "/range/1/day/2022-01-12/2023-01-12?adjusted=true&sort=asc&limit=120&apiKey=" + API_KEY;

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JsonElement jsonElement = JsonParser.parseString(response.toString());
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                JsonObject result = jsonObject.getAsJsonObject("results").getAsJsonObject(stockSymbol);

                double open = result.getAsJsonPrimitive("o").getAsDouble();
                double close = result.getAsJsonPrimitive("c").getAsDouble();
                double high = result.getAsJsonPrimitive("h").getAsDouble();
                double low = result.getAsJsonPrimitive("l").getAsDouble();
                long volume = result.getAsJsonPrimitive("v").getAsLong();
                long timestamp = result.getAsJsonPrimitive("t").getAsLong();

                stockData.addProperty("Open", open);
                stockData.addProperty("Close", close);
                stockData.addProperty("High", high);
                stockData.addProperty("Low", low);
                stockData.addProperty("Volume", volume);
                stockData.addProperty("Timestamp", timestamp);
            } else {
                stockData.addProperty("Error", "HTTP response code " + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
            stockData.addProperty("Error", e.getMessage());
        }

        return stockData;
    }

    public static void logRequestAndResponse(String requestReceivedTime, String responseSentTime, String userAgent,
                                             String apiRequestTime, String apiResponseTime, String symbol,
                                             JsonObject result, String requestUrl) {
        // Log the request and response details to your database or file
        // For demonstration, let's just print the details to the console
        System.out.println("Request Received Time: " + requestReceivedTime);
        System.out.println("Response Sent Time: " + responseSentTime);
        System.out.println("User-Agent: " + userAgent);
        System.out.println("Symbol: " + symbol);
        System.out.println("Result: " + result);
        System.out.println("Request URL: " + requestUrl);
        // Add logic to store this information in your database or file
    }
}
