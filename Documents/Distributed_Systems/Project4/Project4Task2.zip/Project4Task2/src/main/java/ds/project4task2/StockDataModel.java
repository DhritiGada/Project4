// Name: Dhriti Gada
// Andrew id: dgada

package ds.project4task2;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class StockDataModel {
    public String getStockData(String stockSymbol) {
        String apiKey = "https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/day/2023-01-09/2023-01-09?apiKey=LpLxmrARONFWxOriE1k4eMzBCDEG2cBT";
        String apiUrl = "https://api.polygon.io/v2/aggs/ticker/" + stockSymbol + "/range/1/day/2023-01-09/2023-01-09?apiKey=" + apiKey;

        StringBuilder stockData = new StringBuilder();

        try {
            // Create a URL object
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();

            // Check if the response code is OK
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // Parse the JSON response
                JsonElement jsonElement = JsonParser.parseString(response.toString());
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                JsonObject result = jsonObject.getAsJsonObject("results").getAsJsonObject(stockSymbol);

                // Extract desired information from the JSON response
                double open = result.getAsJsonPrimitive("o").getAsDouble();
                double close = result.getAsJsonPrimitive("c").getAsDouble();
                double high = result.getAsJsonPrimitive("h").getAsDouble();
                double low = result.getAsJsonPrimitive("l").getAsDouble();
                long volume = result.getAsJsonPrimitive("v").getAsLong();
                long timestamp = result.getAsJsonPrimitive("t").getAsLong();

                // Build the stock data string
                stockData.append("Open: ").append(open).append(", ");
                stockData.append("Close: ").append(close).append(", ");
                stockData.append("High: ").append(high).append(", ");
                stockData.append("Low: ").append(low).append(", ");
                stockData.append("Volume: ").append(volume).append(", ");
                stockData.append("Timestamp: ").append(timestamp);
            } else {
                // If response code is not OK, append error message to stockData
                stockData.append("Error: HTTP response code ").append(responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stockData.toString();
    }
}